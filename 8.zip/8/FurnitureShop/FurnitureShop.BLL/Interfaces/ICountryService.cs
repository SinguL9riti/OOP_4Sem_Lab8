﻿using FurnitureShop.Domain.Entities;

namespace FurnitureShop.BLL.Interfaces;

public interface ICountryService
{
    public IEnumerable<Country> GetAll();
}
