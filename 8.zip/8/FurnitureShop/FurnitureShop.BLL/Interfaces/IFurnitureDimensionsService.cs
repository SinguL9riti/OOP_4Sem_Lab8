﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.Domain;

namespace FurnitureShop.BLL.Interfaces;

public interface IFurnitureDimensionsService
{
	public IEnumerable<FurnitureDimensions> GetAll();
	public FurnitureDimensions GetBy(string name);
}
