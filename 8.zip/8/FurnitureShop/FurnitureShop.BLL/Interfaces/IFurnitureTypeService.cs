﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.DAL.Repositories;
using FurnitureShop.Domain;

namespace FurnitureShop.BLL.Interfaces;

public interface IFurnitureTypeService
{
	public IEnumerable<FurnitureType> GetAll();
	public FurnitureType GetBy(string name);
}
