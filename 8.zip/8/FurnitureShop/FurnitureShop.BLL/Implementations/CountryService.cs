﻿using FurnitureShop.BLL.Interfaces;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain.Entities;

namespace FurnitureShop.BLL.Implementations;

public class CountryService(IRepository<Country> countryRepository) : ICountryService
{
    private readonly IRepository<Country> _countryRepository = countryRepository;
    public IEnumerable<Country> GetAll()
    {
        return _countryRepository.ReadAll();
    }
}
