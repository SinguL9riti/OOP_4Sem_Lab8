﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.BLL.Interfaces;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain;

namespace FurnitureShop.BLL.Implementations;

public class FurnitureDimensionsService(IRepository<FurnitureDimensions> furnitureDimensionsRepository) : IFurnitureDimensionsService
{
	private readonly IRepository<FurnitureDimensions> _furnitureDimensionsRepository = furnitureDimensionsRepository;

	public IEnumerable<FurnitureDimensions> GetAll()
	{
		return _furnitureDimensionsRepository.ReadAll();
	}

	public FurnitureDimensions GetBy(string name)
	{
		return GetAll().First(x => x.ToString() == name);
	}
}
