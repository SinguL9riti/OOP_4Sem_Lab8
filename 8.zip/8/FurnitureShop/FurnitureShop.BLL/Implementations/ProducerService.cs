﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.BLL.Interfaces;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain;
using FurnitureShop.Domain.Entities;
using FurnitureShop.Domain.ViewModels;

namespace FurnitureShop.BLL.Implementations;

public class ProducerService(IRepository<Producer> producerRepository) : IProducerService
{
	private readonly IRepository<Producer> _producerRepository = producerRepository;
	public IEnumerable<ProducerViewModel> GetAll()
	{
		List<ProducerViewModel> list = [];
		foreach(Producer producer in _producerRepository.ReadAll())
		{
			list.Add(new(producer));
		}
		return list;
	}

	public IEnumerable<Producer> GetAllModels()
	{
		return _producerRepository.ReadAll();
	}

	public Producer GetBy(string name)
	{
		return GetAllModels().First(x => x.Name == name);
	}
}
