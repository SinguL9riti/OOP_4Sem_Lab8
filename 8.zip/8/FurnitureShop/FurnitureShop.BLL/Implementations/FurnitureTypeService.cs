﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.BLL.Interfaces;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain;

namespace FurnitureShop.BLL.Implementations;

public class FurnitureTypeService(IRepository<FurnitureType> furnitureTypeRepository) : IFurnitureTypeService
{
	private readonly IRepository<FurnitureType> _furnitureTypeRepository = furnitureTypeRepository;
	public IEnumerable<FurnitureType> GetAll()
	{
		return _furnitureTypeRepository.ReadAll();
	}

	public FurnitureType GetBy(string name)
	{
		return GetAll().First(x => x.Name == name);
	}
}
