﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FurnitureShop.BLL.Interfaces;
using FurnitureShop.Domain;

namespace FurnitureShop.Pages;

public partial class RemoveFurniturePage : Page
{
	private readonly IFurnitureService _furnitureService;
	public RemoveFurniturePage(IFurnitureService furnitureService)
	{
		_furnitureService = furnitureService;
		InitializeComponent();
	}

	private void RemoveButton_Click(object sender, RoutedEventArgs e)
	{
		try
		{
			if (txtName.Text.Length <= 0)
			{
				MessageBox.Show("Не указано название мебели!");
				return;
			}

			Furniture furniture = new()
			{
				Name = txtName.Text,
			};

			_furnitureService.Remove(furniture);
			MessageBox.Show("Мебель успешно удалена!");
		}
		catch (Exception)
		{
			MessageBox.Show("Не найдено название мебели");
		}
	}
}
