﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FurnitureShop.BLL.Implementations;
using FurnitureShop.BLL.Interfaces;
using FurnitureShop.Domain;
using FurnitureShop.Domain.ViewModels;

namespace FurnitureShop.View;

public partial class FurnitureView : Page
{
	private readonly IFurnitureService _furnitureService;
	private readonly IProducerService _producerService;
	private readonly IFurnitureDimensionsService _dimensionsService;
	private readonly IFurnitureTypeService _typeService;
	public FurnitureView(IFurnitureService furnitureService, IFurnitureDimensionsService dimensionsService,
						 IProducerService producerService, IFurnitureTypeService typeService)
	{
		_furnitureService = furnitureService;
		_dimensionsService = dimensionsService;
		_producerService = producerService;
		_typeService = typeService;

		InitializeComponent();
		dataFurnitures.ItemsSource = _furnitureService.GetAll();
		comboBoxDimensions.ItemsSource = _dimensionsService.GetAll().Select(x => x.ToString());
		comboBoxFurnitureType.ItemsSource = _typeService.GetAll().Select(x => x.Name);
		comboBoxProducer.ItemsSource = _producerService.GetAll().Select(x => x.Name);
	}

	private void DataGrid_PreviewKeyDown(object sender, KeyEventArgs e)
	{
		try
		{
			if (dataFurnitures.SelectedItem is FurnitureViewModel furnitureVM)
			{
				if (e.Key == Key.Delete)
				{
					if (furnitureVM != null)
					{
						Furniture furniture = new()
						{
							Id = furnitureVM.Id,
							Name = furnitureVM.Name,
						};
						_furnitureService.Remove(furniture);
						MessageBox.Show("Данные успешно удалены");
						dataFurnitures.ItemsSource = _furnitureService.GetAll();
					}
				}

				if (e.Key == Key.N)
				{
					Furniture furniture = new()
					{
						Name = $"название мебели{_furnitureService.GetAll().Select(x => x.Id).Last() + 1}",
						Producer = _producerService.GetAllModels().First(),
						Dimensions = _dimensionsService.GetAll().First(),
						Type = _typeService.GetAll().First(),
						Discount = 0,
						Price = 0,
						IsAvailable = false,
					};
					_furnitureService.Add(furniture);
					dataFurnitures.ItemsSource = _furnitureService.GetAll();
				}
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
	}

	private void DataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
	{
		try
		{
			if (e.Row.Item is FurnitureViewModel furnitureVM)
			{
				if (furnitureVM != null)
				{
					Furniture furniture = new()
					{
						Id = furnitureVM.Id,
						Name = furnitureVM.Name,
						Dimensions = _dimensionsService.GetBy(furnitureVM.Dimensions.ToString()),	
						Discount = furnitureVM.Discount,
						IsAvailable= furnitureVM.IsAvailable,
						Price = double.Parse(furnitureVM.Price),
						Producer = _producerService.GetBy(furnitureVM.Producer),
						Type = _typeService.GetBy(furnitureVM.Type),
					};
					_furnitureService.Update(furniture, furniture);
					MessageBox.Show($"Данные успешно изменены");
					dataFurnitures.ItemsSource = _furnitureService.GetAll();
				}
			}
		}
		catch (Exception ex)
		{
			MessageBox.Show(ex.Message);
		}
	}
}
