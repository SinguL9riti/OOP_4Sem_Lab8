﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain;

namespace FurnitureShop.DAL.Repositories;

public class ProducerRepository(IDbContext dbContext) : IRepository<Producer>
{
	private readonly IDbContext _dbContext = dbContext;

	public bool Create(Producer entity)
	{
		_dbContext.Producers.Add(entity);
		_dbContext.SaveChanges();
		return true;
	}

	public bool Delete(Producer entity)
	{
		bool isRemoved = _dbContext.Producers.Remove(entity);
		_dbContext.SaveChanges();
		return isRemoved;
	}

	public Producer Read(int id)
	{
		return ReadAll().First(x => x.Id == id);
	}

	public IEnumerable<Producer> ReadAll()
	{
		return _dbContext.Producers;
	}

	public bool Update(Producer oldEntity, Producer newEntity)
	{
		_dbContext.SaveChanges();
		return true;
	}
}
