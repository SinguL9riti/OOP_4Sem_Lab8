﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain;

namespace FurnitureShop.DAL.Repositories;

public class FurnitureDimensionsRepository(IDbContext dbContext) : IRepository<FurnitureDimensions>
{
	private readonly IDbContext _dbContext = dbContext;	
	public bool Create(FurnitureDimensions entity)
	{
		_dbContext.FurnitureDimensions.Add(entity);
		_dbContext.SaveChanges();
		return true;
	}

	public bool Delete(FurnitureDimensions entity)
	{
		bool isRemoved = _dbContext.FurnitureDimensions.Remove(entity);
		_dbContext.SaveChanges();
		return isRemoved;
	}

	public FurnitureDimensions Read(int id)
	{
		return ReadAll().First(x => x.Id == id);
	}

	public IEnumerable<FurnitureDimensions> ReadAll()
	{
		return _dbContext.FurnitureDimensions;
	}

	public bool Update(FurnitureDimensions oldEntity, FurnitureDimensions newEntity)
	{
		_dbContext.SaveChanges();
		return true;
	}
}
