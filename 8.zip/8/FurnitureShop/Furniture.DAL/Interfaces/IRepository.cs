﻿namespace FurnitureShop.DAL.Interfaces;

public interface IRepository<TEntity> where TEntity : class
{
    public IEnumerable<TEntity> ReadAll();
    public TEntity Read(int id);

    public bool Create(TEntity entity);
    public bool Update(TEntity oldEntity, TEntity newEntity);
    public bool Delete(TEntity entity);
}
