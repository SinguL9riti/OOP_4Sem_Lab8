﻿using FurnitureShop.Domain;
using FurnitureShop.Domain.Entities;

namespace FurnitureShop.DAL.Interfaces;

public interface IDbContext
{
	public List<Country> Countries { get; }
	public List<FurnitureType> FurnitureTypes { get; }
	public List<FurnitureDimensions> FurnitureDimensions { get; }
	public List<Producer> Producers { get; }
	public List<Furniture> Furnitures { get; }
	public void SaveChanges();
}
