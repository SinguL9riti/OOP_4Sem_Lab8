﻿using Azure;
using FurnitureShop.DAL.Interfaces;
using FurnitureShop.Domain;
using FurnitureShop.Domain.Entities;
using Microsoft.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Data.SqlTypes;
using System.Reflection;

namespace FurnitureShop.DAL;

public class DbContextLinq : IDbContext
{
	private readonly SqlConnection _connection;

	private readonly DataTable _dtCountries;
	private readonly DataTable _dtFurnitureTypes;
	private readonly DataTable _dtFurnitureDimensions;
	private readonly DataTable _dtProducers;
	private readonly DataTable _dtFurnitures;


	public List<Country> Countries { get; set; } = [];
	public List<Producer> Producers { get; set; } = [];
    public List<FurnitureType> FurnitureTypes { get; set; } = [];
	public List<FurnitureDimensions> FurnitureDimensions { get; set; } = [];
	public List<Furniture> Furnitures { get; set; } = [];



	public DbContextLinq()
    {
        string settings = ConfigurationManager.ConnectionStrings["DbFurnitureShop"].ConnectionString;
        _connection = new SqlConnection(settings);
		SqlDataAdapter _adapterCountries = new("SELECT * FROM Countries", _connection);
		SqlDataAdapter _adapterFurnitureTypes = new("SELECT * FROM FurnitureTypes", _connection);
		SqlDataAdapter _adapterFurnitureDimensions = new("SELECT * FROM FurnitureDimensions", _connection);
		SqlDataAdapter _adapterProducers = new("SELECT * FROM Producers", _connection);
		SqlDataAdapter _adapterFurnitures = new("SELECT * FROM Furnitures", _connection);

		_dtCountries = new();
		_dtFurnitureTypes = new();
		_dtFurnitureDimensions = new();
		_dtProducers = new();
		_dtFurnitures = new();

		_connection.Open();

		_adapterCountries.Fill(_dtCountries);
		_adapterFurnitureTypes.Fill(_dtFurnitureTypes);
		_adapterFurnitureDimensions.Fill(_dtFurnitureDimensions);
		_adapterProducers.Fill(_dtProducers);
		_adapterFurnitures.Fill(_dtFurnitures);


		_connection.Close();

		SelectFurnitures();
	}

	public void SelectProducers()
	{
		SelectCountries();
		var queryProducers = _dtProducers.AsEnumerable().Select(country => new
		{
			Id = country.Field<int>("ProducerId"),
			Name = country.Field<string>("Name"),
			CountryId = country.Field<int>("CountryId"),
		});

		Producers = [];
		foreach (var query in queryProducers)
		{
			Country country = Countries.Where(c => c.Id == query.CountryId).Single();
			if (query.Name != null)
			{
				Producers.Add(new()
				{
					Id = query.Id,
					Name = query.Name,
					Country = country,
				});
			}
		}
	}

	public void SelectCountries()
    {
		var queryCountries = _dtCountries.AsEnumerable().Select(country => new
		{
			Id = country.Field<int>("CountryId"),
			Name = country.Field<string>("Name"),
		});

		Countries = [];
		foreach (var query in queryCountries)
		{
			if (query.Name != null)
			{
				Countries.Add(new()
				{
					Id = query.Id,
					Name = query.Name,
				});
			}
		}
	}

	public void SelectFurnitureTypes()
	{
		var queryTypes = _dtFurnitureTypes.AsEnumerable().Select(type => new
		{
			Id = type.Field<int>("FurnitureTypeId"),
			Name = type.Field<string>("Name"),
		});

		FurnitureTypes = [];
		foreach (var query in queryTypes)
		{
			if (query.Name != null)
			{
				FurnitureTypes.Add(new()
				{
					Id = query.Id,
					Name = query.Name,
				});
			}
		}
	}

	public void SelectFurnitureDimensions()
	{
		var queryDimensions = _dtFurnitureDimensions.AsEnumerable().Select(dimensions => new
		{
			Id = dimensions.Field<int>("FurnitureDimensionId"),
			Length = dimensions.Field<decimal>("Length"),
			Width = dimensions.Field<decimal>("Width"),
			Height = dimensions.Field<decimal>("Height"),
		});

		FurnitureDimensions = [];
		foreach (var query in queryDimensions)
		{
			FurnitureDimensions.Add(new()
			{
				Id = query.Id,
				Width = (double) query.Width,
				Height = (double) query.Height,
				Length = (double) query.Length,
			});
		}
	}

	public void SelectFurnitures()
	{
		SelectProducers();
		SelectFurnitureDimensions();
		SelectFurnitureTypes();
	
		var queryFurnitures = _dtFurnitures.AsEnumerable().Select(date => new
		{
			Id = date.Field<int>("FurnitureId"),
			FurnitureTypeId = date.Field<int>("FurnitureTypeId"),
			FurnitureDimensionId = date.Field<int>("FurnitureDimensionId"),
			ProducerId = date.Field<int>("ProducerId"),
			Name = date.Field<string>("Name"),
			Price = date.Field<decimal>("Price"),
			Discount = date.Field<int>("Discount"),
			IsAvailable = date.Field<bool>("IsAvailable"),
		});

		Furnitures = [];
		foreach (var query in queryFurnitures)
		{
			if (query.Name != null)
			{
				Producer producer = Producers.Where(o => o.Id == query.ProducerId).Single();
				FurnitureDimensions dimensions = FurnitureDimensions.Where(o => o.Id == query.FurnitureDimensionId).Single();
				FurnitureType type = FurnitureTypes.Where(o => o.Id == query.FurnitureTypeId).Single();
				Furnitures.Add(new()
				{
					Id = query.Id,
					Name = query.Name,
					Type = type,
					Dimensions = dimensions,
					Discount = query.Discount,
					IsAvailable = query.IsAvailable,
					Price = (double) query.Price,
					Producer = producer,
				});
			}
		}
	}    

    private void InsertIntoFurnitures()
    {
		foreach (Furniture furniture in Furnitures)
		{
			DataRow row = _dtFurnitures.NewRow();

			row["FurnitureId"] = furniture.Id;
			row["FurnitureTypeId"] = furniture.Type.Id;
			row["FurnitureDimensionId"] = furniture.Dimensions.Id;
			row["ProducerId"] = furniture.Producer.Id;
			row["Name"] = furniture.Name;
			row["Price"] = furniture.Price;
			row["Discount"] = furniture.Discount;
			row["IsAvailable"] = furniture.IsAvailable;
			

			_dtFurnitures.Rows.Add(row);
		}

		SqlDataAdapter adapter = new()
		{
			InsertCommand = new("INSERT INTO Furnitures (FurnitureTypeId, FurnitureDimensionId, ProducerId, [Name], Price, Discount, IsAvailable) " +
							    "VALUES (@FurnitureTypeId, @FurnitureDimensionId, @ProducerId, @Name, @Price, @Discount, @IsAvailable)", _connection),
		};

		adapter.InsertCommand.Parameters.Add("@FurnitureTypeId", SqlDbType.Int, 4, "FurnitureTypeId");
		adapter.InsertCommand.Parameters.Add("@FurnitureDimensionId", SqlDbType.Int, 4, "FurnitureDimensionId");
		adapter.InsertCommand.Parameters.Add("@ProducerId", SqlDbType.Int, 4, "ProducerId");
		adapter.InsertCommand.Parameters.Add("@Name", SqlDbType.VarChar, 100, "Name");
		adapter.InsertCommand.Parameters.Add("@Price", SqlDbType.Money, 8, "Price");
		adapter.InsertCommand.Parameters.Add("@Discount", SqlDbType.Int, 4, "Discount");
		adapter.InsertCommand.Parameters.Add("@IsAvailable", SqlDbType.Bit, 1, "IsAvailable");
		

		adapter.Update(_dtFurnitures);
		_dtFurnitures.AcceptChanges();
    }

    private void DeleteAll()
    {
		SqlDataAdapter adapter = new()
		{
			DeleteCommand = new("DELETE FROM Furnitures", _connection)
		};
		adapter.DeleteCommand.ExecuteNonQuery();
		_dtFurnitures.Clear();
		adapter.Update(_dtFurnitures);
		_dtFurnitures.AcceptChanges();
    }

    private void UpdateAll()
    {
        DeleteAll();
		InsertIntoFurnitures();
	}

    public void SaveChanges()
    {
		try
		{
			_connection.Open();

			UpdateAll();

		}
		catch(Exception ex) 
		{
			throw new Exception("", ex);
		}
		finally
		{
			_connection.Close();
		}
    }

}