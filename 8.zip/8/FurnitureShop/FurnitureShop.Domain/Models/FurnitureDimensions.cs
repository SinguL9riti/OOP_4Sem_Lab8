﻿using FurnitureShop.Domain.Entities;

namespace FurnitureShop.Domain;

public class FurnitureDimensions(int id, double length, double width, double height)
{
    public int Id { get; set; } = id;
    public double Length { get; set; } = length;
    public double Width { get; set; } = width;
    public double Height { get; set; } = height;

    public FurnitureDimensions():this(0, 0, 0, 0)
    {
        
    }

	public override string ToString()
	{
        return $"{Length}, {Width}, {Height}";
	}
}
