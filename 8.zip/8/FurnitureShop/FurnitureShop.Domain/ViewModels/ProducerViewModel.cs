﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FurnitureShop.Domain.Entities;
using System.Xml.Linq;

namespace FurnitureShop.Domain.ViewModels;

public class ProducerViewModel(Producer producer)
{
	public int Id { get; set; } = producer.Id;
	public string Name { get; set; } = producer.Name;
	public string Country { get; set; } = producer.Country.Name;
}
